from django.shortcuts import render

# Create your views here.
def StaticView(request):
    return render(request,'index.html')