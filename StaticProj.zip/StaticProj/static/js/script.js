function showMessage() {
		alert("Welcome to Static Files Example");
	}
