from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def setcookie(request):
    response = HttpResponse("Cookie Created")
    response.set_cookie('name','Django Student')
    return response

def getcookie(request):
    name = request.COOKIES.get('name')
    return HttpResponse("Cookie Value : " + str(name))

def deletecookie(request):
    response = HttpResponse("Cookie Deleted")
    response.delete_cookie('name')
    return response

def indexview(request):
    return render(request,'home.html')