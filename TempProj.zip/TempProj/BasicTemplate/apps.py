from django.apps import AppConfig


class BasictemplateConfig(AppConfig):
    name = 'BasicTemplate'
