from django.shortcuts import render
import datetime
# Create your views here.
def templateview(request):
    return render(request,'BasicTemplateApp/Sample.html') #render() function sends data to HTML template.

def DTView(request):
    date=datetime.datetime.now()
    my_dict={'insert_date':date}
    return render(request,'BasicTemplateApp/DateTime.html',context=my_dict) #context=my_dict → passes dictionary data to template.

def StudentView(request):
    name='Suresh Yadlapati'
    rollno=3544
    marks=82
    my_dict1={'name':name,'rollno':rollno,'marks':marks}
    return render(request,'BasicTemplateApp/StudentInfo.html',context=my_dict1)

def StudentResultView(request):
    name = 'Suresh Yadlapati'
    rollno = 3544
    marks = 82
    subjects = ['Python', 'Django', 'JAVA']
    my_dict2 = {
        'name': name,
        'rollno': rollno,
        'marks': marks,
        'subjects': subjects
    }
    return render(request, 'BasicTemplateApp/StudentResults.html', context=my_dict2)