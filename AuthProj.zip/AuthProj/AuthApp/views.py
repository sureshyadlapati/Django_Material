from django.shortcuts import render

# Create your views here. 
# Temporary dictionary (only while server runs)
users = {}
def registerview(request):
    message = ""
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        users[username] = password
        message = "Registration Successful"

    return render(request, 'register.html', context={'message': message})


def loginview(request):
    message = ""
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username in users and users[username] == password:
            message = "Login Successful"
        else:
            message = "Invalid Credentials"

    return render(request, 'login.html', context={'message': message})

def indexview(request):
   return render(request, 'index.html') 