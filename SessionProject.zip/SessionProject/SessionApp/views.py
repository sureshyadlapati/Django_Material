from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def setsession(request):
    request.session['name'] = "Suresh Yadlapati"
    return HttpResponse("Session Created")

def getsession(request):
    name = request.session.get('name')
    return HttpResponse("Session Value : " + str(name))

def deletesession(request):
    del request.session['name']
    return HttpResponse("Session Deleted")

def indexview(request):
    return render(request,'home.html')