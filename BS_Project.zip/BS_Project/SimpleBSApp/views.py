from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'home.html')

def home1(request):
    return render(request, 'Grid_Table.html')

def home2(request):
    return render(request, 'carousel.html')


def index(request):
    return render(request, 'index.html')