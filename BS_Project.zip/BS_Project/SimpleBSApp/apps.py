from django.apps import AppConfig


class SimplebsappConfig(AppConfig):
    name = 'SimpleBSApp'
