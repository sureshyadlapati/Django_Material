from django import forms

class StudentForm(forms.Form):
    name = forms.CharField(label="Name", max_length=50)
    age = forms.IntegerField(label="Age")