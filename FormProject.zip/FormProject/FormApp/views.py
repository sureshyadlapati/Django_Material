from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from .forms import StudentForm

def student_form(request):
    form = StudentForm()
    return render(request, "studentform.html", {"form": form})